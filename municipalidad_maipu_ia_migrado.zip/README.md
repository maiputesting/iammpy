# Migración: Municipalidad Maipú IA

## Estructura

- `backend/` – API REST con FastAPI y SQLite (SQLAlchemy).
- `gradio_app/` – Interfaz de chatbot con Gradio.
- `streamlit_dashboard/` – Dashboard interactivo con Streamlit.
- `docker-compose.yml` – Orquestación de contenedores.

## Requisitos

- Docker & Docker Compose
- Archivo `.env` basado en `.env.example`.

## Montaje

1. Clonar el repositorio:
   ```bash
   git clone <tu-repo-url>.git
   cd municipalidad_maipu_ia_migrado
   cp .env.example .env
   # Completar variables en .env
   ```

2. Iniciar servicios:
   ```bash
   docker-compose up --build
   ```

3. Acceder a:
   - Backend: `http://localhost:8000/health/`
   - Chatbot (Gradio): `http://localhost:7860/`
   - Dashboard (Streamlit): `http://localhost:8501/`
