from pydantic import BaseSettings, HttpUrl

class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite+aiosqlite:///./maipu_ia.db"
    OPENAI_API_KEY: str
    CORS_ORIGINS: list[str] = ["http://localhost:7860", "http://localhost:8501"]
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = "../.env"

settings = Settings()
