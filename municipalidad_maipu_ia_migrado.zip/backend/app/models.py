from sqlalchemy import Column, Integer, String, Text, DateTime, func
from .db import Base

class ChatLog(Base):
    __tablename__ = "chat_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_input = Column(Text, nullable=False)
    bot_response = Column(Text, nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

class ImageCheck(Base):
    __tablename__ = "image_checks"
    id = Column(Integer, primary_key=True, index=True)
    image_url = Column(String, nullable=False)
    status = Column(String, nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
