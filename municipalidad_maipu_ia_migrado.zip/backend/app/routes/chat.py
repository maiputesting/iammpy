from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import AsyncSessionLocal
from ..schemas import ChatRequest, ChatResponse
from ..models import ChatLog
from ..services.ai_service import generate_reply

router = APIRouter(tags=["chat"], prefix="/chat")

async def get_db():
    async with AsyncSessionLocal() as session:
        yield session

@router.post("/", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest, db: AsyncSession = Depends(get_db)):
    reply = await generate_reply(req.message)
    log = ChatLog(user_input=req.message, bot_response=reply)
    db.add(log)
    await db.commit()
    return ChatResponse(reply=reply)
