from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from ..schemas import ImageCheckRequest, ImageCheckResponse
from ..models import ImageCheck
from ..db import AsyncSessionLocal
import httpx

router = APIRouter(tags=["check_images"], prefix="/check-images")

async def get_db():
    async with AsyncSessionLocal() as session:
        yield session

@router.post("/", response_model=ImageCheckResponse)
async def check_image(req: ImageCheckRequest, db: AsyncSession = Depends(get_db)):
    async with httpx.AsyncClient(timeout=5) as client:
        r = await client.head(str(req.url))
    status = "ok" if r.status_code == 200 else "fail"
    record = ImageCheck(image_url=str(req.url), status=status)
    db.add(record)
    await db.commit()
    return ImageCheckResponse(url=req.url, status=status)
