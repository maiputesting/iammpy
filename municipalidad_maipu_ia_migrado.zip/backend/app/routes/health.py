from fastapi import APIRouter
from ..schemas import HealthResponse

router = APIRouter(tags=["health"], prefix="/health")

@router.get("/", response_model=HealthResponse)
async def health_check():
    return {"status":"ok"}
