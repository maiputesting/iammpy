from pydantic import BaseModel, HttpUrl

class HealthResponse(BaseModel):
    status: str

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str

class ImageCheckRequest(BaseModel):
    url: HttpUrl

class ImageCheckResponse(BaseModel):
    url: HttpUrl
    status: str
