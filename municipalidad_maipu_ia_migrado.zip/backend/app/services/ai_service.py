import openai
from fastapi import HTTPException
from ..config import settings

openai.api_key = settings.OPENAI_API_KEY

async def generate_reply(prompt: str) -> str:
    try:
        resp = await openai.ChatCompletion.acreate(
            model="gpt-3.5-turbo",
            messages=[{"role":"user","content":prompt}],
            max_tokens=150
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI service error: {e}")
