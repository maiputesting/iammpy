import gradio as gr
import requests

API_URL = "http://backend:8000/chat/"

def gradio_chat(message: str) -> str:
    resp = requests.post(API_URL, json={"message": message})
    return resp.json().get("reply", f"Error {resp.status_code}")

with gr.Blocks(title="Chatbot Maipú IA") as demo:
    gr.Markdown("# 🤖 Chatbot Municipalidad Maipú")
    chat = gr.Chatbot()
    msg = gr.Textbox()
    send = gr.Button("Enviar")

    def handle(user_message, history):
        reply = gradio_chat(user_message)
        return history + [(user_message, reply)], ""

    send.click(fn=handle, inputs=[msg, chat], outputs=[chat, msg])

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860)
