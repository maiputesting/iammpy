import streamlit as st
import pandas as pd
import sqlite3

DB_PATH = "../backend/maipu_ia.db"

st.set_page_config(page_title="Dashboard Maipú IA", layout="wide")
st.title("📊 Dashboard Municipalidad Maipú IA")

@st.cache_data
def load_data(table):
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
    conn.close()
    return df

tabs = st.tabs(["Chat Logs", "Image Checks"])
with tabs[0]:
    st.header("Historial de Chat")
    st.dataframe(load_data("chat_logs"))
with tabs[1]:
    st.header("Verificación de Imágenes")
    st.dataframe(load_data("image_checks"))
